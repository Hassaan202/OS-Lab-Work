#include <stdio.h>
#include<unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>

void removeNonAlphabetChars(char* iFile, char* oFile){
    int fdInput=open(iFile, O_RDONLY);
    int fdOutput=open(oFile, O_WRONLY);
    char* buffer=(char*)calloc(100, sizeof(char));
    int bytesRead=read(fdInput, buffer, 100);
    printf("%d bytes read from inFile.txt\n", bytesRead);
    int currSize=0;
    for (int i=0;i<bytesRead;i++){
        if ((buffer[i]>='a' && buffer[i]<='z') || (buffer[i]>='A' && buffer[i]<='Z')){
            //if it is an alphabet character
            buffer[currSize]=buffer[i];
            currSize=currSize+1;
        }
        //Note that space is also removed as it is a non-alpahbet character
    }
    // buffer[currSize]='\0';
    printf("%s\n", buffer);
    int bytesWritten=write(fdOutput, buffer, currSize);
    printf("%d bytes wriiten into outFile.txt\n", bytesWritten);
    close(fdInput);
    close(fdOutput);
    free(buffer); //deallocates the memory
}

int main(){
    removeNonAlphabetChars("inFile.txt", "outFile.txt");
    
    return 0;
}
