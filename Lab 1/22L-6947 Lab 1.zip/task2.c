#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main(){
    int pid = fork();
    int pid1=fork();
    if (pid==0){
        printf("This is a child process.\n");
    }
    else{
        printf("This is a parent process.\n");
    }

    if (pid1==0){
        printf("This is a child process.(2)\n");
    }
    else {
        printf("This is a parent process.(2)\n");
    }

    return 0;
}

// Process Tree
            //        P
            //     /     \
            //     P      C
            //    / \    / \
            //   P  C1  C  c2
        