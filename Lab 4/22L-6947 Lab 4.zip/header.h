#include <iostream>
#include <algorithm>
using namespace std;

void sort(int arr[], int n, bool order);
void findHighest(int arr[], int n, int& position);
void print(int arr[], int n);