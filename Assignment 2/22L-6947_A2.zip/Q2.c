#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

int main(){
      int fd[2];
      if (pipe(fd)){
            perror("Pipes not working correctly.\n");
            return 1;
      }
      int pid=fork();
      if (pid==0){
            //child
            int bankNum=1;
            int bankbalance=200;
            printf("Enter the amount to withdraw:");
            int withdraw=0;
            scanf("%d", &withdraw);
            bankbalance-=withdraw;
            close(fd[0]);
            int bytesWritten=write(fd[1], &bankbalance, sizeof(int));
            close(fd[1]);
      }
      else{
            //parent
            int bankbalance=0;
            close(fd[1]);
            int bytesRead=read(fd[0], &bankbalance, sizeof(int));
            close(fd[0]);
            printf("Remaining amount: %d.\n", bankbalance);
      }

      return 0;
}